document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("vehiclePassForm");
    const previewBtn = document.getElementById("previewBtn");
    const submitBtn = document.getElementById("submitBtn");

    // Preview Button Functionality
    if (previewBtn) {
        previewBtn.addEventListener("click", function () {
            const formData = getFormData();
            localStorage.setItem("vehiclePassData", JSON.stringify(formData));
            window.open("preview.html", "_blank");
        });
    }

    // Load Data in Preview Page
    const previewDetails = document.getElementById("previewDetails");
    if (previewDetails) {
        const formData = JSON.parse(localStorage.getItem("vehiclePassData"));
        if (formData) {
            let detailsHTML = "";
            for (const key in formData) {
                if (formData[key].trim() !== "") {
                    detailsHTML += `<p><strong>${formatLabel(key)}:</strong> ${formData[key]}</p>`;
                }
            }
            previewDetails.innerHTML = detailsHTML;
        }
    }

    // Submit Button Functionality (Save to Database)
    if (submitBtn) {
        submitBtn.addEventListener("click", async function () {
            const formData = JSON.parse(localStorage.getItem("vehiclePassData"));

            if (!formData) {
                alert("No data found to submit!");
                return;
            }

            const response = await fetch("php/save_pass.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData)
            });

            const result = await response.json();
            alert(result.message);

            if (result.success) {
                localStorage.removeItem("vehiclePassData"); // Clear data after submission
                window.print(); // Print the pass
            }
        });
    }
});

// Helper Function: Get Form Data
function getFormData() {
    return {
        passNo: document.getElementById("passNo").value,
        date: document.getElementById("date").value,
        name: document.getElementById("name").value,
        regnNo: document.getElementById("regnNo").value,
        dlNo: document.getElementById("dlNo").value,
        referenceNo: document.getElementById("referenceNo").value,
        purpose: document.getElementById("purpose").value,
        area: document.getElementById("area").value,
        timeIn: document.getElementById("timeIn").value,
        timeOut: document.getElementById("timeOut").value
    };
}

// Helper Function: Format Labels for Display
function formatLabel(key) {
    return key.replace(/([A-Z])/g, " $1").replace(/^./, str => str.toUpperCase());
}

