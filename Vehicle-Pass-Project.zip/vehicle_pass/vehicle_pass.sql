CREATE DATABASE IF NOT EXISTS vehicle_pass_db;

USE vehicle_pass_db;

CREATE TABLE IF NOT EXISTS vehicle_pass (
    id INT AUTO_INCREMENT PRIMARY KEY,
    passNo VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    name VARCHAR(100) NOT NULL,
    regnNo VARCHAR(50) NOT NULL,
    dlNo VARCHAR(50) NOT NULL,
    referenceNo VARCHAR(50) NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    area VARCHAR(255) NOT NULL,
    timeIn TIME NOT NULL,
    timeOut TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
